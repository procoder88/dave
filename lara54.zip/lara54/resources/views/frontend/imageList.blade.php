<div class="row fix" id="imgList">
	@forelse($rsp_obj['photos']['photo'] as $photo)
		<div class="col-xs-12 col-sm-3">
			<a href="#" data-photoid='{{ $photo["id"] }}' class="viewDetail thumbnail fix" >
				<img src='http://farm{{ $photo["farm"] }}.static.flickr.com/{{ $photo["server"] }}/{{ $photo["id"] }}_{{ $photo["secret"] }}_t.jpg' />
			</a>
		</div>
	@empty
		<h3 class="text-danger">No images to display.</h3>
	@endforelse
</div>