<div class="row" id="imgDetail">
	<div class="col-xs-12 col-md-6">
		<img class="img-responsive" src='http://farm{{ $rsp_obj["photo"]["farm"] }}.static.flickr.com/{{ $rsp_obj["photo"]["server"] }}/{{ $rsp_obj["photo"]["id"] }}_{{ $rsp_obj["photo"]["secret"] }}.jpg' />
	</div>
	<div class="col-xs-6 col-md-6">
		<div class="row">
			<div class="col-xs-12 col-md-8">
				<h4>{{ $rsp_obj['photo']['description']['_content'] }}</h4>
			</div>
			<div class="col-xs-4 col-md-4">
				<button type="button" class="btn btn-labeled btn-default" id="imgBack">
					<span class="btn-label-default"><i class="glyphicon glyphicon-chevron-left"></i></span>Back
				</button>
			</div>
	</div>

</div>
</div>