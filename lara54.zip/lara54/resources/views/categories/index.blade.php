@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-primary">
                <div class="panel-heading">Categories</div>
                <div class="panel-body">
                    <div class="row pull-right" style="margin-bottom: 10px; margin-right: 2px;">
                        <a href="categories/create" class="btn btn-success">Create a category</a>
                    </div>
                    <div class="clearfix"></div>
                    <div class="row">
                    <ul class="list-group">
                    @forelse($categories as $category)
                        <li class="list-group-item">
                            {{ $category->name }}
                            <div class="pull-right action-buttons">
                                <a href="/categories/{{ $category->id }}/edit" ><span class="glyphicon glyphicon-pencil"></span></a>

                                    <form action="categories/{{ $category->id }}" method="POST" style="display: inline">
                                        {{ csrf_field() }}
                                        {{ method_field('DELETE') }}
                                        <button class="btn btn-link btn-sm text-danger trash"><span class="glyphicon glyphicon-trash"></span></button>
                                    </form>
                            </div>
                        </li>
                    @empty
                        <h3>There are no categories set.</h3>
                    @endforelse
                    </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
