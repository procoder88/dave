$(document).ready(function(){
    $.ajax({
        url: '/showCategories',
        type: 'GET',
        dataType: 'json',
        success: function(data){
            $.each(data, function(i, j){
                $('#categories').append('<a href="#" data-categ="'+j.name+'" class="list-group-item viewImages">'+j.name+'</a>');
            });
        }
    });

    $('.content').on('click', '.viewImages', function(e){
        e.preventDefault();
        var categ = $(this).data('categ');
        //remove the active
        $('.viewImages').removeClass('active');
        //activate current category
        $(this).addClass('active');
        $('#loader-block').html('loading...');
        //show the title
        $('#title').children('h1').html(categ+' Photo Gallery');
        $.ajax({
            url: '/showImages/'+categ,
            type: 'GET',
            dataType: 'html',
            success: function(data){
                $('#loader-block').html(data);
            }
        });
    });

    $('#loader-block').on('click', '.viewDetail', function(e){
        e.preventDefault();
        var imgid = $(this).data('photoid');
        $('#imgList').hide();
        $('#imgDetail').remove();
        $.ajax({
            url: '/showImage/'+imgid,
            type: 'GET',
            dataType: 'html',
            success: function(data){
                $('#loader-block').append(data);
            }
        });
    });

    $('#loader-block').on('click', '#imgBack', function(e){
        e.preventDefault();
        $('#imgDetail').remove();
        $('#imgList').show();
        
    });
});