<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-primary">
                <div class="panel-heading">Categories</div>
                <div class="panel-body">
                    <div class="row pull-right" style="margin-bottom: 10px; margin-right: 2px;">
                        <a href="categories/create" class="btn btn-success">Create a category</a>
                    </div>
                    <div class="clearfix"></div>
                    <div class="row">
                    <ul class="list-group">
                    <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <li class="list-group-item">
                            <?php echo e($category->name); ?>

                            <div class="pull-right action-buttons">
                                <a href="/categories/<?php echo e($category->id); ?>/edit" ><span class="glyphicon glyphicon-pencil"></span></a>

                                    <form action="categories/<?php echo e($category->id); ?>" method="POST" style="display: inline">
                                        <?php echo e(csrf_field()); ?>

                                        <?php echo e(method_field('DELETE')); ?>

                                        <button class="btn btn-link btn-sm text-danger trash"><span class="glyphicon glyphicon-trash"></span></button>
                                    </form>
                            </div>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <h3>There are no categories set.</h3>
                    <?php endif; ?>
                    </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>