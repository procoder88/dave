<!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Raleway:100,600" rel="stylesheet" type="text/css">

        <!-- Styles -->
        <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('css/custom_frontend.css')); ?>" rel="stylesheet">
    </head>
    <body>
        <div class="full-height">

            <div class="content container">
                <div class="row">
                    <div class="col-xs-12 text-center" id="title">
                        <h1>Gallery Categories</h1>
                    </div>
                </div>
                <div class="row">
                    <div class="col-xs-12 col-sm-3 pull-left">
                        <div class="list-group" id="categories"></div>
                    </div>
                    <div class="col-xs-12 col-sm-9" id="loader-block">
                        <h3>Select a category to see the images here.</h3>
                    </div>
                </div>
            </div>
        </div>

        <!-- Scripts -->
        <script src="<?php echo e(asset('js/app.js')); ?>"></script>
        <script type="text/javascript" src="<?php echo e(asset('js/functionality.js')); ?>"></script>
    </body>
</html>
