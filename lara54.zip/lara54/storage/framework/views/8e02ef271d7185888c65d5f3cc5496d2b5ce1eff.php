<div class="row" id="imgDetail">
	<div class="col-md-8">
		<img src='http://farm<?php echo e($rsp_obj["photo"]["farm"]); ?>.static.flickr.com/<?php echo e($rsp_obj["photo"]["server"]); ?>/<?php echo e($rsp_obj["photo"]["id"]); ?>_<?php echo e($rsp_obj["photo"]["secret"]); ?>.jpg' />
	</div>
<div class="col-md-4">
	<div><a href="" id="imgBack" class="pull-right">Back</a></div>
	<div><?php echo e($rsp_obj['photo']['description']['_content']); ?></div>
</div>
</div>