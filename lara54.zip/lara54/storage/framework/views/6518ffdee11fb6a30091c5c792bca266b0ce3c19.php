<div class="row" id="imgList">
	<?php $__empty_1 = true; $__currentLoopData = $rsp_obj['photos']['photo']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
		<a href="#" data-photoid='<?php echo e($photo["id"]); ?>' class="viewDetail" ><img src='http://farm<?php echo e($photo["farm"]); ?>.static.flickr.com/<?php echo e($photo["server"]); ?>/<?php echo e($photo["id"]); ?>_<?php echo e($photo["secret"]); ?>_t.jpg' /></a>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
		<h3 class="text-danger">No images to display.</h3>
	<?php endif; ?>
</div>