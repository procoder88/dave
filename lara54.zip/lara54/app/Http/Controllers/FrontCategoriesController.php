<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Category;

class FrontCategoriesController extends Controller
{
    public function getCategories()
    {
    	$categories = Category::all();

    	return json_encode($categories);
    }

    public function getImages($categ='')
    {

		$params = array(
			'method'	=> 'flickr.photos.search',
			'text'	=> $categ,
			'per_page' => 50,
			'sort' => 'relevance'
		);

		$rsp_obj = $this->callApi($params);		

		if ($rsp_obj['stat'] !== 'ok'){
			return "Call failed!";
		}else{
			return view('frontend.imageList', compact('rsp_obj'));
		}
    }

    public function getOneImage($id='')
    {
    	$params = array(
			'method'	=> 'flickr.photos.getInfo',
			'photo_id' => $id
		);

		$rsp_obj = $this->callApi($params);	
		// echo '<pre>'; print_r($rsp_obj); die();	

		if ($rsp_obj['stat'] !== 'ok'){
			return "Call failed!";
		}else{
			return view('frontend.imageDetail', compact('rsp_obj'));
		}
    }

    private function callApi($params_new=array())
    {
    	$params_default = array(
			'api_key'	=> env('FLICKR_KEY', ''),
			'format'	=> 'php_serial',
		);

		$params = array_merge($params_default, $params_new);

		$encoded_params = array();

		foreach ($params as $k => $v){

			$encoded_params[] = urlencode($k).'='.urlencode($v);
		}


		#
		# call the API and decode the response
		#

		$url = "https://api.flickr.com/services/rest/?".implode('&', $encoded_params);

		$rsp = file_get_contents($url);

		$rsp_obj = unserialize($rsp);

		return $rsp_obj;
    }
}
